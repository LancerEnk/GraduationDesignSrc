'use strict';

require('./shim')();

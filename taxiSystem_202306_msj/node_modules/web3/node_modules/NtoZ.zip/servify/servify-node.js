module.exports = require("./servify")({
    "express": require("express"),
    "cors": require("cors"),
    "request": require("request"),
    "body-parser": require("body-parser")
});

module.exports = require("./servify")({xhr: require("xhr")});

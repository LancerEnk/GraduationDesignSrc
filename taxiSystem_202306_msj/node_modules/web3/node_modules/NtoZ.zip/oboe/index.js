var oboe = require('./dist/oboe-node')

module.exports = oboe

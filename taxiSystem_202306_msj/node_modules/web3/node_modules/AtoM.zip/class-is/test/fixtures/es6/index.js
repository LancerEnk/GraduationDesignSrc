'use strict';

module.exports = {
    Animal: require('./Animal'),
    Plant: require('./Plant'),
    Mammal: require('./Mammal'),
    Algae: require('./Algae'),
};
